﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_des_etudiants
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        string choix = "";
        string n, p;
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            comboBox1.Visible = false;
            con.Open();
            
            if (radioButton1.Checked)
            {
                choix = "M";
            }
            else
            {
                choix = "F";
            }
            cmd.CommandText=("insert into etudiant values('" + textBox7.Text + "','" + textBox1.Text + "','" + textBox2.Text + "','" + choix + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','"+ textBox8.Text+ "','" + textBox6.Text + "')");
            cmd.ExecuteNonQuery();
            MessageBox.Show("Etudiant enrégistrer avec succès!");
            con.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DIALLO\\SQLEXPRESS;Initial Catalog=gestion_etudiant;Integrated Security=True");
            cmd = new SqlCommand("", con);

            con.Open();
            cmd.CommandText = "select nom, prenom from etudiant";
            dr = cmd.ExecuteReader();
            while (dr.Read())
                comboBox1.Items.Add(dr[0]+ " " + dr[1]);
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "" && textBox4.Text == "" && textBox5.Text == "")
            {
                comboBox1.Visible = true;
            }
            else
            {

                if (radioButton1.Checked)
                {
                    choix = "M";
                }
                else
                {
                    choix = "F";
                }
                con.Open();
                cmd.CommandText = "update etudiant set matricule='" + textBox7.Text + "',nom='" + textBox1.Text + "',prenom ='" + textBox2.Text +
                    "',sexe='" + choix + "',date_N='" + textBox3.Text + "',adresse='" + textBox4.Text + "',tel='" +
                    textBox5.Text + "',note='"+textBox6.Text+ "',filiere='" + textBox8.Text + "'where nom ='" + n + "' and prenom='" + p + "'";
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Modifier avec succès!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "" && textBox4.Text == "" && textBox5.Text == "")
            {
                comboBox1.Visible = true;
            }
            else
            {
                con.Open();
                if (MessageBox.Show("Voulez-vous vraiment supprimer " + n + " " + p + " ?", "Supprimer etudiant", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning) == System.Windows.Forms.DialogResult.Yes)
                {
                    cmd.CommandText = "delete from etudiant where nom='" + n + "' and prenom='" + p + "'";
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Etudiant"+n+" "+p+" Supprimer de la liste avec succès!");
                }
                con.Close();
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            comboBox1.Visible = false;
            //connexion à la base de donnéess
            SqlConnection con = new SqlConnection("Data Source=DIALLO\\SQLEXPRESS;Initial Catalog=gestion_etudiant;Integrated Security=True");
            //ouverture de la connection
            con.Open();
            //exécution de la commande sql
            SqlCommand cmd = new SqlCommand("select * from etudiant where Matricule=@matricule or Filiere=@filiere", con);
            cmd.Parameters.AddWithValue("Matricule", textBox7.Text);
            cmd.Parameters.AddWithValue("Filiere", textBox8.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string r = comboBox1.SelectedItem.ToString();//récuperation du nom et du prenom sélectionné dans le comboBox
            n = r.Substring(0, comboBox1.Text.IndexOf(" "));//permet de récupérer le nom a partir de la premier lettre indexé
            p = r.Substring(comboBox1.Text.IndexOf(" ") + 1);//permet de récupérer le prenom
            textBox1.Text = n;
            textBox2.Text = p;

            con.Open();
            cmd.CommandText = "select sexe, date_N, adresse, tel, note, matricule,filiere from etudiant";
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (dr[0] == "M")
                {
                    radioButton1.Checked = true;
                }
                else
                {
                    radioButton2.Checked = true;
                }
                textBox3.Text = dr[1].ToString();
                textBox4.Text = dr[2].ToString();
                textBox5.Text = dr[3].ToString();
                textBox6.Text = dr[4].ToString();
                textBox7.Text = dr[5].ToString();
                textBox8.Text = dr[6].ToString();

            }
                
            con.Close();
        }
    }
}
